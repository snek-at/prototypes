import SnekTemplate from "./snek";
interface IMainTemplate {
    snek: SnekTemplate;
}
declare class MainTemplate implements IMainTemplate {
    snek: SnekTemplate;
}
export type { IMainTemplate };
export { MainTemplate };

import * as _general from "./general";
import * as _user from "./user";
declare class SnekGqlQuery {
    general: typeof _general;
    user: typeof _user;
}
export { SnekGqlQuery };

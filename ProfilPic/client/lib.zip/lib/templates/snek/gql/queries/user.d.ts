declare const whoami: import("graphql").DocumentNode;
declare const profile: import("graphql").DocumentNode;
export { whoami, profile };

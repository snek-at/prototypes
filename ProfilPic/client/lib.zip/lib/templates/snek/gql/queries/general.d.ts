declare const gitlabServer: import("graphql").DocumentNode;
declare const allPageUrls: import("graphql").DocumentNode;
export { gitlabServer, allPageUrls };

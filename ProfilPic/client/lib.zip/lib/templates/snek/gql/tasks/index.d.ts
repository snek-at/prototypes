import { SnekSession } from "../../../../session/sessions";
import SnekGqlAuthTasks from "./auth";
import SnekGqlGeneralTasks from "./general";
import SnekGqlUserTasks from "./user";
interface IResponse {
    errors: [];
}
declare class SnekTasks {
    general: SnekGqlGeneralTasks;
    auth: SnekGqlAuthTasks;
    user: SnekGqlUserTasks;
    constructor(session: SnekSession);
}
export type { IResponse };
export default SnekTasks;

import { SnekSession } from "../../../../session/sessions";
import { IResponse } from "./index";
import { ISnekGqlTemplate } from "../index";
interface IRegistrationResponse extends IResponse {
    data: RegistrationData;
}
interface RegistrationData {
    result: string;
    errors: [];
}
interface ICacheResponse extends IResponse {
    data: CacheData;
}
interface CacheData {
    user: {
        id: number;
    };
}
interface IProfileResponse extends IResponse {
    data: ProfileData;
}
interface ProfileData {
    username: string;
    firstName: string;
    lastName: string;
    email: string;
    verified: string;
    platformData: string;
    sources: string;
    bids: string;
    tids: string;
}
interface IWhoamiResponse extends IResponse {
    data: WhoamiData;
}
interface WhoamiData {
    username: string;
}
declare class SnekGqlUserTasks {
    private session;
    template: ISnekGqlTemplate;
    constructor(session: SnekSession);
    registration(values: object): Promise<IRegistrationResponse>;
    cache(platformData: string): Promise<ICacheResponse>;
    profile(url: string): Promise<IProfileResponse>;
    whoami(): Promise<IWhoamiResponse>;
}
export default SnekGqlUserTasks;

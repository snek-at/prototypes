import { SnekSession } from "../../../../session/sessions";
import { IResponse } from "./index";
import { ISnekGqlTemplate } from "../index";
interface IGitlabServerResponse extends IResponse {
    data: {
        page: GitlabServerData;
    };
}
interface GitlabServerData {
    supportedGitlabs: [];
}
interface IAllPageUrlResponse extends IResponse {
    data: {
        pages: [];
    };
}
declare class SnekGqlGeneralTasks {
    private session;
    template: ISnekGqlTemplate;
    constructor(session: SnekSession);
    gitlabServer(): Promise<IGitlabServerResponse>;
    allPageUrls(): Promise<IAllPageUrlResponse>;
}
export default SnekGqlGeneralTasks;

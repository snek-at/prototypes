import { SnekSession } from "../../../../session/sessions";
import { User } from "../../../../session";
import { IResponse } from "./index";
import { ISnekGqlTemplate } from "../index";
interface IAuthResponse extends IResponse {
    data: {
        auth: AuthData;
    };
    errors: [];
}
interface AuthData {
    token: string;
    refreshToken: string;
    user: {
        username: string;
    };
}
interface IRefreshResponse extends IResponse {
    data: {
        refresh: RefreshData;
    };
}
interface RefreshData {
    payload: string;
    token: string;
    refreshToken: string;
}
interface IRevokeResponse extends IResponse {
    data: {
        revoke: RevokeData;
    };
}
interface RevokeData {
    revoked: string;
}
declare class SnekGqlAuthTasks {
    private session;
    template: ISnekGqlTemplate;
    constructor(session: SnekSession);
    anon(): Promise<IAuthResponse>;
    nonanon(user: User): Promise<IAuthResponse>;
    refresh(): Promise<IRefreshResponse>;
    revoke(): Promise<IRevokeResponse>;
}
export default SnekGqlAuthTasks;

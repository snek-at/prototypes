import { SnekGqlQuery } from "./queries/index";
import { SnekGqlMutation } from "./mutations/index";
interface ISnekGqlTemplate {
    queries: SnekGqlQuery;
    mutations: SnekGqlMutation;
}
declare class SnekGql {
    queries: SnekGqlQuery;
    mutations: SnekGqlMutation;
}
export type { ISnekGqlTemplate };
export default SnekGql;

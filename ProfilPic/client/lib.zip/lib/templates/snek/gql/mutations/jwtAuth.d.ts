declare const auth: import("graphql").DocumentNode;
declare const refresh: import("graphql").DocumentNode;
declare const verify: import("graphql").DocumentNode;
declare const revoke: import("graphql").DocumentNode;
export { auth, refresh, verify, revoke };

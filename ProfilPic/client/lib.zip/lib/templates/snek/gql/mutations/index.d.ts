import * as _jwtAuth from "./jwtAuth";
import * as _user from "./user";
declare class SnekGqlMutation {
    jwtAuth: typeof _jwtAuth;
    user: typeof _user;
}
export { SnekGqlMutation };

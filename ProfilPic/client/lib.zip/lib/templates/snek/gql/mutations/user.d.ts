declare const registration: import("graphql").DocumentNode;
declare const cache: import("graphql").DocumentNode;
export { registration, cache };

import SnekGql from "./gql";
declare class SnekTemplate {
    snekGql: SnekGql;
}
export default SnekTemplate;

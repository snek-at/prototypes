import { ScraperEndpoint, IOptions } from "./index";
declare class Scraper implements ScraperEndpoint {
    private root;
    headers: object;
    desc: string;
    constructor(root: string, options: IOptions);
    getJson<T>(path: string): Promise<T>;
    getDom(path: string): Promise<Document>;
}
export default Scraper;

import { DocumentNode } from "graphql";
interface IEndpoint {
    headers: {};
    desc: string;
}
interface IOptions {
    headers: object;
}
interface ApolloEndpoint extends IEndpoint {
    send: (type: string, data: DocumentNode, variables?: object, headers?: object) => Promise<object>;
}
interface ScraperEndpoint extends IEndpoint {
    getJson<T>(url: string): Promise<T>;
    getDom(url: string): Promise<Document>;
}
export type { IOptions, ApolloEndpoint, ScraperEndpoint };

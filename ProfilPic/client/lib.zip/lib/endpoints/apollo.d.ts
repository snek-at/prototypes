import { DocumentNode } from "graphql";
import { ApolloEndpoint, IOptions } from "./index";
declare class Apollo implements ApolloEndpoint {
    private link;
    private cache;
    private client;
    headers: object;
    desc: string;
    constructor(uri: string, options: IOptions);
    send(type: string, data: DocumentNode, variables?: object, headers?: object): Promise<Error | import("apollo-client").ApolloQueryResult<any> | import("apollo-link").FetchResult<any, Record<string, any>, Record<string, any>>>;
}
export default Apollo;

import { SnekSession, GithubSession } from "./session/sessions";
import { ScraperEndpoint, ApolloEndpoint } from "./endpoints/index";
import { IMainTemplate } from "./templates/index";
interface IEndpoint {
    url: string;
    type: string;
    headers: object;
}
interface IClient {
}
declare class Client implements IClient {
    constructor(ep: IEndpoint);
}
declare class SnekClient extends Client {
    endpoint: ApolloEndpoint;
    template: IMainTemplate;
    session: SnekSession;
    constructor(type?: string, url?: string, headers?: object);
}
declare class GithubClient extends Client {
    endpoint: ApolloEndpoint;
    template: IMainTemplate;
    session: GithubSession;
    constructor(url?: string, type?: string, headers?: object);
}
declare class GitlabClient extends Client {
    endpointScraper: ScraperEndpoint;
    constructor(url?: string, type?: string, headers?: object);
}
export { SnekClient, GithubClient, GitlabClient };

import Session from "./index";
import { IMainTemplate } from "../templates/index";
import SnekTemplate from "../templates/snek/index";
import SnekTasks from "../templates/snek/gql/tasks/index";
import { DocumentNode } from "graphql";
import { ApolloEndpoint } from "../../src/endpoints/index";
import { IAuth, User, UserData } from "./index";
declare class GithubSession extends Session {
    ep: ApolloEndpoint;
    template: IMainTemplate;
    constructor(sId: string, ep: ApolloEndpoint, template: IMainTemplate);
    send(token: string, data: DocumentNode, variables?: object): Promise<object>;
}
declare class SnekSession extends Session {
    ep: ApolloEndpoint;
    template: SnekTemplate;
    refreshToken: string | undefined;
    refreshTokenName: string;
    tasks: SnekTasks;
    constructor(sId: string, ep: ApolloEndpoint, template: SnekTemplate);
    send(token: string, data: DocumentNode, variables?: object): Promise<object>;
    initTokens(auth: IAuth): void;
    wasAlive(): boolean;
    isAlive(): boolean;
    begin(user?: User): Promise<UserData>;
    refresh(): Promise<void>;
    end(): Promise<void>;
}
export { GithubSession, SnekSession };

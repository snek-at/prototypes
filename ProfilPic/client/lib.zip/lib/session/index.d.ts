interface UserData {
    username?: string;
    firstName?: string;
    lastName?: string;
    ownedPages?: string;
    email?: string;
    dateJoined?: string;
    lastLogin?: string;
}
interface IAuth {
    token: string;
    refreshToken: string;
}
interface User {
    username: string;
    password: string;
}
interface ISession {
    sessions: {
        [id: string]: ISession;
    };
    token: string | undefined;
    tokenName: string;
}
declare class Session implements ISession {
    private sId;
    sessions: {
        [id: string]: ISession;
    };
    token: string | undefined;
    tokenName: string;
    constructor(sId: string);
    addSubSession<S, E, T>(childSId: string, Cls: any, endpoint: E, template: T): S;
    isAlive(): boolean;
}
export type { UserData, IAuth, User, ISession };
export default Session;

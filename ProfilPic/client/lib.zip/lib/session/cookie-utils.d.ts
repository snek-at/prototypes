declare function setCookie(name: string, val: string, time: number): void;
declare function getCookie(name: string): string | undefined;
declare function deleteCookie(name: string): void;
declare function cookieChecker(name: string): boolean;
export { setCookie, getCookie, deleteCookie, cookieChecker };
